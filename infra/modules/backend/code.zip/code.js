module.exports.handler = async () => {
  return {
    statusCode: 200,
    headers: {},
    body: 'PLACEHOLDER',
  };
};
